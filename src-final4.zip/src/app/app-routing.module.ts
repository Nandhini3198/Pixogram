import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignUpComponent } from './sign-up/sign-up.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import { SearchComponent } from './search/search.component';
import { UploadPageComponent } from './upload-page/upload-page.component';

const routes: Routes = [
  {path: '', component:SignInComponent, pathMatch: 'full'},
  {path: 'sign-up/sign-in', component:SignInComponent, pathMatch: 'full'},
  {path: 'sign-up', component:SignUpComponent, pathMatch: 'full'},
  {path: 'getStarted', component:UserLandingComponent, pathMatch: 'full'},
  {path: 'search', component:SearchComponent, pathMatch: 'full'},
  {path: 'upload', component:UploadPageComponent, pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
