import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  constructor(private userService:UserService,private router:Router) { }
  username:string;
  password:string;
  user:User;
  ngOnInit() {
  }
 
  signin()
  {
    this.userService.checkLogin(this.username,this.password).subscribe((data:User)=>{console.log(data)
      this.createUser(data)});
  }
  createUser(data:User)
  {
   this.user=data;
   window.localStorage.setItem('username',this.user.username);
  }

  start()
  {
    this.router.navigate(['getStarted'])

  }
}
