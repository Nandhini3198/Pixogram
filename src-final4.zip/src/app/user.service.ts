import { Injectable } from '@angular/core';
import {HttpClient, HttpRequest, HttpEvent} from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  

  username:string=window.localStorage.getItem('username');
  private baseUrl='http://localhost:8080/api';
  constructor(private http:HttpClient) { }

  createUser(user:User):Observable<any>{
    return this.http.post<User>(`${this.baseUrl}/create`,user);
  }

  checkLogin(username: string, password: string):Observable<any> {
    return this.http.get<User>(`${this.baseUrl}/checkLogin/${username}/${password}`);
  }

  upload(imageURL:string){
    return this.http.get(`${this.baseUrl}/upload/${this.username}/${imageURL}`)
  }
  pushFileToStorage(file: File, username, url, title, description, tags): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();

    formdata.append('file', file, url);
    formdata.append('username', this.username);
    formdata.append('url', url);
    formdata.append('title', title);
    formdata.append('description', description);
    formdata.append('tags', tags);

    const req = new HttpRequest('POST', `${this.baseUrl}/post`, formdata, {
      reportProgress: true,
      responseType: 'text'
    });

    return this.http.request(req);
  }


}
