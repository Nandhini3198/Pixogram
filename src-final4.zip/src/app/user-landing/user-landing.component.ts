import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-landing',
  templateUrl: './user-landing.component.html',
  styleUrls: ['./user-landing.component.css']
})
export class UserLandingComponent implements OnInit {

  constructor(private route:Router) { }
  username:string=window.localStorage.getItem('username')
  ngOnInit() {

  }

  search()
  {
 this.route.navigate(["search"]);
  }
  upload()
  {
    this.route.navigate(["upload"]);
  }

}
