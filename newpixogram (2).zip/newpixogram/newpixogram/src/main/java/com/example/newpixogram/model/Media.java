package com.example.newpixogram.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "media")
public class Media {

	
	@Column(name="username")
	private String username;
	
	
	@Column(name="image")
	private String imageURL;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="image_id")
	private int image_id;
	



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getImageURL() {
		return imageURL;
	}


	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}


	public Media(String username, String imageURL) {
		super();
		this.username = username;
		this.imageURL = imageURL;
	}


	public Media() {
		super();
	}



	@Override
	public String toString() {
		return "Media [username=" + username + ", imageURL=" + imageURL + ", image_id=" + image_id + "]";
	}
	
	

	
	
}
