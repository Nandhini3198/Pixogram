package com.example.newpixogram;

import java.util.stream.Stream;

import javax.annotation.Resource;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.newpixogram.model.Media;
import com.example.newpixogram.repository.MediaRepository;
import com.example.newpixogram.service.StorageService;

@SpringBootApplication
public class NewpixogramApplication implements CommandLineRunner{
	
	@Resource
	StorageService storageService;
	
	@Resource
	MediaRepository mediaRepo;

	public static void main(String[] args) {
		SpringApplication.run(NewpixogramApplication.class, args);
	}
	



@Bean
ApplicationRunner init1(MediaRepository mediaRepo, StorageService storageService) {
return args -> {
Stream.of(new Media("nans", "dummy1.jpg")).forEach(media -> {
mediaRepo.save(media);
});
mediaRepo.findAll().forEach(System.out::println);
};
}




@Override
public void run(String... args) throws Exception {
	// TODO Auto-generated method stub
	
}
}
