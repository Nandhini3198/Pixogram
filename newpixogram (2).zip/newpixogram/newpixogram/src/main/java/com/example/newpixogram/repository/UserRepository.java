package com.example.newpixogram.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.example.newpixogram.model.User;

public interface UserRepository extends CrudRepository<User,Integer> {
	
	@Query("Select c From User c where c.username = :username and c.password = :password")
	User findUser(String username, String password);

}
