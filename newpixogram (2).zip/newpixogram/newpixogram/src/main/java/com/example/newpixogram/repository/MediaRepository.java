package com.example.newpixogram.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.newpixogram.model.Media;

public interface MediaRepository extends JpaRepository<Media, String> {

}
