package com.example.newpixogram.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.newpixogram.model.Media;
import com.example.newpixogram.model.User;
import com.example.newpixogram.repository.MediaRepository;
import com.example.newpixogram.repository.UserRepository;
import com.example.newpixogram.service.StorageService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class UserController {

	
	@Autowired
	UserRepository userrepo;
	
	@Autowired
	MediaRepository mediarepo;
	
	@Autowired
	 StorageService storageService;
	
	@PostMapping(value="/create")
	public User registerUser(@RequestBody User user) {
		System.out.println("hiiiiii");


		// new
		// User(user.getUsername(),user.getPassword(),user.getFirstname(),user.getLastname(),user.getContact_number(),user.getReg_datetime(),user.getReg_code(),user.getActive())
		User _user = userrepo.save(user);
		return _user;

	}
	@GetMapping("/checkLogin/{username}/{password}")
	public User checkUser(@PathVariable ("username") String username,@PathVariable ("password") String password)
	{
		System.out.println("login");
		User _user=userrepo.findUser(username,password);
		System.out.println("login");
		return _user;
	}
	
	@GetMapping("upload/{username}/{imageURL}")
	public void uploadMedia(@PathVariable ("username") String username,@PathVariable ("imageURL") String imageURL)
	{
		System.out.println("image");
		Media m=new Media(username,imageURL);
		mediarepo.save(m);
		
	}
	List<String> files = new ArrayList<String>();

	@PostMapping("/post")
	public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile file,
	@RequestParam("username") String username, @RequestParam("url") String url, @RequestParam("title") String title,
	@RequestParam("description") String description, @RequestParam("tags") String tags) {
	System.out.println(url);
	Media m = mediarepo.save(new Media(username, url));
	System.out.println(m);
	String message = "";
	try {
	storageService.store(file);
	files.add(file.getOriginalFilename());

	message = "You successfully uploaded " + file.getOriginalFilename() + "!";
	return ResponseEntity.status(HttpStatus.OK).body(message);
	} catch (Exception e) {
	message = "FAIL to upload " + file.getOriginalFilename() + "!";
	return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
	}
	}
	
	
}
